package com.myfences;


import java.sql.Connection;
import java.sql.DriverManager;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

// Plain old Java Object it does not extend as class or implements 
// an interface

// The class registers its methods for the HTTP GET request using the @GET annotation. 
// Using the @Produces annotation, it defines that it can deliver several MIME types,
// text, XML and HTML. 

// The browser requests per default the HTML MIME type.

//Sets the path to base URL + /hello
@Path("/user")
public class User {
	private static Connection con=null;
	private static final String DB_CONNECTION = "jdbc:oracle:thin:@geodb.usc.edu:1521:GEODBS";
	private static final String DB_USER = "team7";
	private static final String DB_PASSWORD = "team7";

	
  // This method is called if TEXT_PLAIN is request
  @GET
  @Path("/{i}")
  @Produces(MediaType.TEXT_PLAIN)
  public String putFence(@PathParam("i")String i)
  {
	    java.sql.Statement statement=null;
	    String[] insert_param=i.split(",");
	    String uname=insert_param[0];//user name for new user...need to change table in server to hve uname as PK
	    String pwd=insert_param[1];//password
	    String umode=insert_param[2];//1-admin,0-normal user
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			con = DriverManager.getConnection(DB_CONNECTION, DB_USER,DB_PASSWORD);
			statement = con.createStatement();
			String sql="insert into usertbl values('"+uname+"','"+pwd+"',"+umode+")";
			System.out.println(sql);
			statement.execute(sql);
			System.out.println("Record is inserted into user table!");
			return "<status>success</status>";
		} catch (Exception e) {
			// TODO Auto-generated catch block
			return "<status>error</status>";
		}
	    
  }

} 

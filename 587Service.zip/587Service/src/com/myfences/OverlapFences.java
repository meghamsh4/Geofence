package com.myfences;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.PathParam;
import oracle.sdoapi.OraSpatialManager;
import oracle.sdoapi.adapter.GeometryAdapter;
import oracle.sdoapi.geom.CoordPoint;
import oracle.sdoapi.geom.Geometry;
import oracle.sql.STRUCT;

// Plain old Java Object it does not extend as class or implements 
// an interface

// The class registers its methods for the HTTP GET request using the @GET annotation. 
// Using the @Produces annotation, it defines that it can deliver several MIME types,
// text, XML and HTML. 

// The browser requests per default the HTML MIME type.

//Sets the path to base URL + /hello
@Path("/overlapfence")
public class OverlapFences {
	private static Connection con = null;

	private static final String DB_CONNECTION = "jdbc:oracle:thin:@geodb.usc.edu:1521:GEODBS";
	private static final String DB_USER = "team7";
	private static final String DB_PASSWORD = "team7";
	static Connection mainConnection = null;

	// @GET here defines, this method will method will process HTTP GET
	// requests.
	@SuppressWarnings("deprecation")
	@GET
	// @Path here defines method level path. Identifies the URI path that a
	// resource class method will serve requests for.
	@Path("/currentloc/{cord}")
	// @Produces here defines the media type(s) that the methods
	// of a resource class can produce.
	@Produces(MediaType.TEXT_XML)
	// @PathParam injects the value of URI parameter that defined in @Path
	// expression, into the method.
	public String getOverlapFence(@PathParam("cord") String cord) {
		System.out.println("Inside servlet");
		java.sql.Statement statement = null;
		String result = "";
		String[] location = cord.split(",");
		double xcod = Double.parseDouble(location[0]);
		double ycod = Double.parseDouble(location[1]);
		try {

			Class.forName("oracle.jdbc.driver.OracleDriver");
			con = DriverManager.getConnection(DB_CONNECTION, DB_USER,
					DB_PASSWORD);
			statement = con.createStatement();
			String overlapfencequery = "SELECT f.fence_id,f.fence_shape,f.expirationtime,f.validity,f.info,f.security_level, SDO_NN_DISTANCE(1) dist FROM FENCES f WHERE SDO_NN(f.FENCE_SHAPE,  mdsys.sdo_geometry(2001, 4326, mdsys.sdo_point_type("
					+ xcod
					+ ","
					+ ycod
					+ ",NULL), NULL, NULL), 'sdo_num_res=5', 1) = 'TRUE' AND mdsys.SDO_NN_DISTANCE(1)<=20 and validity=1 and expirationtime>current_timestamp(6)";
           			
			ResultSet rs = statement.executeQuery(overlapfencequery);
			result += "<fences>";

			while (rs.next()) {
				result += "<fence>";
				result += "<fenceid>" + rs.getString(1) + "</fenceid>";
				GeometryAdapter sdoAdapter = OraSpatialManager
						.getGeometryAdapter("SDO", "9", STRUCT.class, null,
								null, con);
				STRUCT struct = (STRUCT) rs.getObject(2);

				Geometry geom = sdoAdapter.importGeometry(struct);
				oracle.sdoapi.geom.Polygon poly = (oracle.sdoapi.geom.Polygon) geom;
				oracle.sdoapi.geom.CurveString cs = poly.getExteriorRing();
				oracle.sdoapi.geom.LineString lineString = (oracle.sdoapi.geom.LineString) cs;
				CoordPoint[] tempPoints = lineString.getPointArray();
				String points = "";
				for (int i = 0; i < tempPoints.length; i++) {

					points += tempPoints[i].getX() + ",";
					points += tempPoints[i].getY() + ";";
				}
				result += "<coordinates>" + points + "</coordinates>";

				result += "<expiry>" + rs.getString(3) + "</expiry>";
				result += "<validity>" + rs.getString(4) + "</validity>";
				result += "<info>" + rs.getString(5) + "</info>";
				result += "<security_level>" + rs.getString(6)
						+ "</security_level>";
				result += "<distance>" + rs.getString(7) + "</distance>";
				result += "</fence>";
			}
			result += "</fences>";
			statement.close();
			con.close();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			// finally block used to close resources
			try {
				if (statement != null)
					statement.close();
			} catch (SQLException se1) {
			}// nothing we can do
			try {
				if (con != null)
					con.close();
			} catch (SQLException se2) {
				se2.printStackTrace();
			}
		}
		return result;

	}

	static Connection getDBConnection() {
		if (mainConnection != null)
			return mainConnection;

		try {
			// loading Oracle Driver
			System.out.print("Looking for Oracle's jdbc-odbc driver ... ");

			System.out.println(", Loaded.");

			System.out.print("Connecting to DB...");
			mainConnection = DriverManager.getConnection(DB_CONNECTION,
					DB_USER, DB_PASSWORD);
			System.out.println(", Connected!");
		} catch (Exception e) {
			System.out.println("Error while connecting to DB: " + e.toString());
			e.printStackTrace();
			System.exit(-1);
		}
		return mainConnection;

	}

}
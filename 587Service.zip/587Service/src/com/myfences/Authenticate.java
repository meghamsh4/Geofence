package com.myfences;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;


// Plain old Java Object it does not extend as class or implements 
// an interface

// The class registers its methods for the HTTP GET request using the @GET annotation. 
// Using the @Produces annotation, it defines that it can deliver several MIME types,
// text, XML and HTML. 

// The browser requests per default the HTML MIME type.

//Sets the path to base URL + /authenticate
@Path("/authenticate")
public class Authenticate {
	private static Connection con=null;
	
	private static final String DB_CONNECTION = "jdbc:oracle:thin:@geodb.usc.edu:1521:GEODBS";
	private static final String DB_USER = "team7";
	private static final String DB_PASSWORD = "team7";
	static Connection mainConnection=null;

  @GET
  @Path("/{j}")
  @Produces(MediaType.TEXT_XML)
  public String getUser(@PathParam("j")String j)
  {
	    System.out.println("Inside servlet");
	  	java.sql.Statement statement=null;
	  	String result="";
	  	String[] params=j.split(",");
	  	String uname=params[0];
	  	String pwd=params[1];
		try 
		{ 
			int flag=0;
			String mode="";
			Class.forName("oracle.jdbc.driver.OracleDriver");
			con = DriverManager.getConnection(DB_CONNECTION, DB_USER,DB_PASSWORD);
			statement = con.createStatement();
			ResultSet rs=statement.executeQuery("select * from usertbl");		
			while(rs.next())
			{
				String user=rs.getString(1);
				String pass=rs.getString(2);
				if(user.trim().equals(uname) && pass.trim().equals(pwd))
				{
					flag=1;
					mode=rs.getString(3);
					break;
				}
			}
			rs.close();
			statement.close();
			con.close();
			if(flag==1)
			{
				result+="<status>"+mode+"</status>";
				//if mode is 0 or 1 valid user
			}
			else
			{
				result+="<status>Invalid</status>";
				//if status is invalid not a valid user
			}
					
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return result;
	
  }
			    
  static Connection getDBConnection(){
		 if(mainConnection != null)
			 return mainConnection;
		 
				try
				{
					// loading Oracle Driver
		    		System.out.print("Looking for Oracle's jdbc-odbc driver ... ");
			    	
			    	System.out.println(", Loaded.");

					
			    	System.out.print("Connecting to DB...");
			    	mainConnection = DriverManager.getConnection(DB_CONNECTION, DB_USER,DB_PASSWORD);
			    	System.out.println(", Connected!");
		   		}
		   		catch (Exception e)
		   		{
		     		System.out.println( "Error while connecting to DB: "+ e.toString() );
		     		e.printStackTrace();
		     		System.exit(-1);
		   		}
				return mainConnection;	    
	}
} 
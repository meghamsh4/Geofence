package com.myfences;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

// Plain old Java Object it does not extend as class or implements 
// an interface

// The class registers its methods for the HTTP GET request using the @GET annotation. 
// Using the @Produces annotation, it defines that it can deliver several MIME types,
// text, XML and HTML. 

// The browser requests per default the HTML MIME type.

//Sets the path to base URL + /hello
@Path("/insert")
public class Insert {
	private static Connection con=null;
	private static final String DB_CONNECTION = "jdbc:oracle:thin:@geodb.usc.edu:1521:GEODBS";
	private static final String DB_USER = "team7";
	private static final String DB_PASSWORD = "team7";

	
  // This method is called if TEXT_PLAIN is request
  @GET
  @Path("/{i}")
  @Produces(MediaType.TEXT_PLAIN)
  public String putFence(@PathParam("i")String i)
  {
	    System.out.println("Inside Insert");
	    /*here i contains data to be inserted. 
	     *Insert in the following order only
	     *FenceID,FenceShape(coordinates),
	     *ExpirationTime,Validity(0/1),Info,
	     *Security Level.If some field is Null leave 
	     *it empty(i.e a,,b,c)
	     */
	    java.sql.Statement statement=null;
	    String[] insert_param=i.split(",");
	    String id=insert_param[0];
	    StringBuffer coordinates=new StringBuffer();
	    
	    String validity=null;
	    int j=1;
	    while(j<insert_param.length-4)
	    {
	    	coordinates.append(insert_param[j]+",");
	    	j++;
	    }
	    coordinates.append(insert_param[1]+","+insert_param[2]);
	    String timestamp=insert_param[j++];
	    validity=insert_param[j++];
	    String info=insert_param[j++];
	    String sec_lev=insert_param[j++];
	    for(int k=0;k<insert_param.length;k++)
	    {
	    	System.out.println(insert_param[k]);
	    }
	    
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			con = DriverManager.getConnection(DB_CONNECTION, DB_USER,DB_PASSWORD);
			statement = con.createStatement();
			String sql="insert into fences values("+
			id+",sdo_geometry(2003,4326,NULL,SDO_ELEM_INFO_ARRAY(1,1003,1)," +
					"SDO_ORDINATE_ARRAY("+coordinates.toString()+")),TIMESTAMP '"+timestamp+"',"+validity+",'"+info+"',"+sec_lev+")";
			System.out.println(sql);
			statement.execute(sql);
			System.out.println("Record is inserted into fences table!");
			statement.close();
			con.close();
			return "<status>success</status>";
		} catch (Exception e) {
			// TODO Auto-generated catch block
			return "<status>error</status>";
			//e.printStackTrace();
		}finally {
			// finally block used to close resources
			try {
				if (statement != null)
					statement.close();
			} catch (SQLException se1) {
			}// nothing we can do
			try {
				if (con != null)
					con.close();
			} catch (SQLException se2) {
				se2.printStackTrace();
			}
		}
	    
  }

} 
